import calculadora_indices as calc


print("Calculadora de IMC")
peso = int(input("Ingrese el peso de la persona en KG"))
Altura = float(input("Ingrese la altura de la persona en metros"))

iMC=calc.calcular_IMC(peso,Altura)

print(f"El indice de masa corporal es {iMC}")
